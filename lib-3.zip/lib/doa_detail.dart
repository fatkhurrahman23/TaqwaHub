// doa_detail_page.dart
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';

Future<Map<String, dynamic>> fetchDoaDetail(int id) async {
  final response = await http.get(Uri.parse('https://open-api.my.id/api/doa/$id'));

  if (response.statusCode == 200) {
    return json.decode(response.body);
  } else {
    throw Exception('Failed to load doa detail');
  }
}

class DoaDetailPage extends StatelessWidget {
  final int id;

  DoaDetailPage({required Key key, required this.id}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Doa Detail'),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: fetchDoaDetail(id),
        builder: (BuildContext context, AsyncSnapshot<Map<String, dynamic>> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          } else {
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  ListTile(
                    title: Text(
                      snapshot.data!['arab'],
                      style: GoogleFonts.rubik(
                        fontSize: 16.0,
                      ),
                      textAlign: TextAlign.right
                    ),
                    subtitle: Text(
                      snapshot.data!['terjemah'],
                      style: TextStyle(fontSize: 12.0),
                    ),
                  ),
                  Divider(),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}